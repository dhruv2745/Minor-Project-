# 🌱 CloudAgri Studio
### Autonomous Precision Agriculture & Farm Digital Twin Simulator

CloudAgri Studio is an enterprise precision agriculture and farm digital twin simulation platform inspired by modern AgTech cloud studios. It provides real-time multi-zone IoT soil telemetry, computer vision plant pathology diagnostics, FAO-56 Penman-Monteith smart irrigation, predictive crop yield forecasting, and ESG carbon credit accounting.

---

## 🌟 Key Platform Capabilities

### 1. Interactive 500-Acre Farm Digital Twin
- **Multi-Zone Agricultural Monitoring:** Monitored parcels including Winter Wheat, Sweet Corn, Premium Vineyard, Smart Hydroponic Greenhouse, and Organic Soybeans.
- **Multispectral Map Overlays:**
  - True Color High-Res Satellite View.
  - Infrared NDVI (Normalized Difference Vegetation Index) crop vigor heatmap.
  - Soil Moisture saturation zone contour mapping.
- **Autonomous Drone Telemetry:** Dispatches animated multispectral aerial drones to scan field parcels and synchronize sensor nodes.

### 2. AI Plant Disease & Computer Vision Pathology Lab
- **Neural Lesion Detection:** Analyzes leaf imagery to identify crop pathogens (*Alternaria solani*, *Exserohilum turcicum*, *Phytophthora infestans*, *Puccinia striiformis*) with >96% neural model confidence.
- **Dynamic Bounding Box Annotation:** Visualizes localized fungal sporulation and necrotic patches on leaf surfaces.
- **Severity Quantification:** Computes foliage damage percentage (e.g., 34% leaf area necrotic).
- **Three-Tier Agronomic Prescriptions:**
  - **Organic / Biological Control:** Beneficial microbes (*Bacillus subtilis*, *Trichoderma*) and copper bio-formulations.
  - **Targeted Chemical Control:** Active ingredients and exact dilution dosages per hectare.
  - **Cultural & Microclimate Adjustments:** Drip conversion, canopy aeration, and crop residue tillage.

### 3. Smart Irrigation & Variable Rate Technology (VRT)
- **Closed-Loop Evapotranspiration Engine:** Calculates daily atmospheric water demand ($ET_0$) using the international standard **FAO-56 Penman-Monteith formulation**.
- **Automated Solenoid Valves:** Automatically actuates irrigation when soil moisture falls below crop-specific depletion thresholds.
- **Water Conservation Accounting:** Tracks total gallons and utility expenditures saved compared to conventional flood irrigation.

### 4. Predictive Yield Modeling & Harvest Forecasting
- **Multi-Variate Agronomic Forecaster:** Predicts harvest yield per acre based on moisture stress coefficients ($K_s$), soil NPK fertility, and Cumulative Growing Degree Days (GDD).
- **Crop Economics:** Projects gross revenues and operational expenditures (OpEx) for grain, fruit, and vegetable crops.
- **Carbon Credit Sequestration Ledger:** Quantifies metric tons of $CO_2$ sequestered via regenerative no-till farming with verified offset credit earnings.

### 5. Hyper-Local Micro-Climate Station
- 7-day hourly meteorological forecast tracking ambient temperature, solar radiation (W/m²), relative humidity, wind speed, and precipitation probability.
- Severe weather early-warning broadcasts (Heatwave, Frost Risk, Torrential Rain).

---

## 📂 Project Architecture
```
ai-farming-simulator/
│
├── index.html                   # Core dashboard (Twin Map, Vision Lab, VRT, Yield, Weather, Economics)
├── styles.css                   # Forest-tech theme, glassmorphic telemetry cards, laser scanner animations
├── farm_simulator.js           # 500-acre digital twin simulation engine, IoT sensors, weather events
├── disease_vision.js           # AI computer vision pathology lab, lesion detector & prescriptions
├── yield_engine.js             # FAO-56 Penman-Monteith ET0, GDD, yield prediction & carbon credits
├── app.js                       # UI controller, telemetry loop, drone surveys & canvas rendering
├── server.py                    # Local Python web server with auto-browser launch
├── run_farming_simulator.bat    # 1-click Windows runner script
├── vercel.json                  # 1-click Vercel deployment configuration
├── netlify.toml                 # 1-click Netlify deployment configuration
├── images/                      # High-detail SVG pathology samples and aerial satellite maps
│   ├── tomato_early_blight.svg
│   ├── corn_northern_blight.svg
│   ├── potato_late_blight.svg
│   ├── wheat_yellow_rust.svg
│   ├── healthy_crop.svg
│   └── farm_satellite_map.svg
└── README.md                    # Platform documentation
```

---

## 🚀 Quick Start: How to Run Locally

### Option 1: One-Click Windows Launch (Recommended)
Simply **double-click** the file:
```
run_farming_simulator.bat
```
This automatically boots the local Python telemetry server and opens the platform in your default browser at `http://localhost:8080`.

### Option 2: Python Command Line
```bash
python server.py
```

### Option 3: Direct Browser Launch
Double-click `index.html` to run in Google Chrome, Microsoft Edge, Brave, or Firefox. Everything executes 100% client-side with zero dependencies!

---

## 🌐 Instant Free Hosting (Live in 10 Seconds)

1. Open **[https://app.netlify.com/drop](https://app.netlify.com/drop)** in your web browser.
2. Drag and drop the `ai-farming-simulator` project folder (or `ai-farming-simulator.zip`).
3. Netlify will instantly generate a live, secure HTTPS URL (e.g. `https://cloudagri-studio.netlify.app`)!
