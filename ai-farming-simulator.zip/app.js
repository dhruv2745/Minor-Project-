/**
 * CloudAgri Studio - Main Application Controller
 * Coordinates Farm Digital Twin Canvas, AI Disease Scanner,
 * Smart Irrigation VRT Matrix, and Telemetry Updates.
 */

class CloudAgriApp {
    constructor() {
        this.activeMapLayer = "natural";
        this.droneAnimating = false;
        this.dronePosition = { x: 50, y: 50 };
        this.droneTarget = { x: 350, y: 150 };
    }

    init() {
        // Connect Simulation Telemetry
        window.farmSimulator.onTick = (summary) => {
            this.handleTelemetryTick(summary);
        };

        // Initialize First Zone Display
        this.selectZone("zone-a");

        // Load Default Disease Sample
        this.loadDiseaseSample("tomato_blight");

        // Render VRT Table
        this.renderVrtTable();

        // Start Map Canvas Overlay
        this.initCanvasMapOverlay();
    }

    switchView(viewName) {
        const views = {
            farm: document.getElementById('viewFarm'),
            disease: document.getElementById('viewDisease'),
            irrigation: document.getElementById('viewIrrigation'),
            yield: document.getElementById('viewYield'),
            weather: document.getElementById('viewWeather'),
            economics: document.getElementById('viewEconomics')
        };

        Object.keys(views).forEach(key => {
            if (views[key]) views[key].classList.remove('active');
        });

        const navIds = ['navFarm', 'navDisease', 'navIrrigation', 'navYield', 'navWeather', 'navEconomics'];
        navIds.forEach(id => document.getElementById(id)?.classList.remove('active'));

        if (views[viewName]) {
            views[viewName].classList.add('active');
        }

        const navBtnMap = {
            farm: 'navFarm',
            disease: 'navDisease',
            irrigation: 'navIrrigation',
            yield: 'navYield',
            weather: 'navWeather',
            economics: 'navEconomics'
        };
        if (navBtnMap[viewName]) {
            document.getElementById(navBtnMap[viewName])?.classList.add('active');
        }

        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // -------------------------------------------------------------
    // Telemetry & Simulation Tick
    // -------------------------------------------------------------
    handleTelemetryTick(summary) {
        // Update Header Clock
        document.getElementById('simClockDisplay').innerText = `Day ${summary.day} | ${summary.time}`;

        // Update High-Level Telemetry
        let totalMoist = 0;
        let totalNdvi = 0;
        let totalWater = 0;

        summary.zones.forEach(z => {
            totalMoist += z.moisture;
            totalNdvi += z.ndvi;
            totalWater += z.waterUsageGal;
        });

        const avgMoist = (totalMoist / summary.zones.length).toFixed(1);
        const avgNdvi = (totalNdvi / summary.zones.length).toFixed(2);

        document.getElementById('statAvgMoisture').innerText = `${avgMoist}%`;
        document.getElementById('statAvgNdvi').innerText = avgNdvi;
        document.getElementById('statWaterSaved').innerText = `${(142400 + totalWater * 0.15).toLocaleString(undefined, {maximumFractionDigits:0})} Gal`;

        document.getElementById('statWeatherCondition').innerText = `${summary.temp}°C | ${summary.humidity}%`;
        document.getElementById('statWeatherSub').innerText = summary.weather;

        // Update Inspector if viewing current selected zone
        const selected = summary.selectedZone;
        if (selected) {
            this.updateZoneInspectorUI(selected);
        }

        // Update VRT Table
        this.renderVrtTable();
    }

    selectZone(zoneId) {
        window.farmSimulator.selectedZoneId = zoneId;
        const summary = window.farmSimulator.getSummary();
        const zone = summary.zones.find(z => z.id === zoneId) || summary.zones[0];
        this.updateZoneInspectorUI(zone);
    }

    updateZoneInspectorUI(zone) {
        document.getElementById('inspectorZoneTitle').innerText = zone.name;
        document.getElementById('inspectorHealthBadge').innerText = zone.healthStatus;
        document.getElementById('inspectorHealthBadge').className = `hud-pill ${zone.moisture < 25 ? '' : 'active'}`;

        document.getElementById('inspectorMoisture').innerText = `${zone.moisture}%`;
        document.getElementById('inspectorMoistureBar').style.width = `${Math.min(100, zone.moisture)}%`;

        document.getElementById('inspectorNdvi').innerText = zone.ndvi;
        document.getElementById('inspectorNdviBar').style.width = `${Math.min(100, zone.ndvi * 100)}%`;

        document.getElementById('inspectorSoilTemp').innerText = `${zone.soilTemp}°C`;
        document.getElementById('inspectorPh').innerText = `${zone.ph} (Optimal)`;

        document.getElementById('inspectorN').innerText = zone.nitrogen;
        document.getElementById('inspectorP').innerText = zone.phosphorus;
        document.getElementById('inspectorK').innerText = zone.potassium;

        document.getElementById('inspectorStage').innerText = zone.stage;
        document.getElementById('inspectorHarvest').innerText = `${zone.daysToHarvest} Days`;

        const irrEl = document.getElementById('inspectorIrrigation');
        irrEl.innerText = zone.irrigationStatus;
        irrEl.className = `hud-pill ${zone.valveOpen ? 'active' : ''}`;

        const valveBtn = document.getElementById('btnToggleValve');
        valveBtn.innerText = zone.valveOpen ? "🛑 Close Variable Rate Valve" : "💧 Activate Variable Rate Irrigation";
    }

    toggleSelectedValve() {
        const zoneId = window.farmSimulator.selectedZoneId;
        const isOpen = window.farmSimulator.toggleIrrigation(zoneId);
        const valveBtn = document.getElementById('btnToggleValve');
        valveBtn.innerText = isOpen ? "🛑 Close Variable Rate Valve" : "💧 Activate Variable Rate Irrigation";
    }

    applyFertilizerToSelected() {
        const zoneId = window.farmSimulator.selectedZoneId;
        window.farmSimulator.applyFertilizer(zoneId);
        alert(`Precision liquid fertigation applied to ${zoneId.toUpperCase()}. Soil NPK enhanced and leaf chlorophyll boosted.`);
    }

    // -------------------------------------------------------------
    // Simulation Clock Controls
    // -------------------------------------------------------------
    togglePlayPause() {
        const running = window.farmSimulator.togglePlayPause();
        const btn = document.getElementById('simPlayBtn');
        btn.innerText = running ? "⏸ Pause" : "▶ Resume";
        btn.classList.toggle('active', running);
    }

    setSpeed(speed) {
        window.farmSimulator.setSpeed(speed);
        ['speed1x', 'speed5x', 'speed24x'].forEach(id => {
            document.getElementById(id)?.classList.remove('active');
        });
        document.getElementById(`speed${speed}x`)?.classList.add('active');
    }

    triggerWeatherEvent(eventName) {
        window.farmSimulator.triggerWeatherEvent(eventName);
    }

    // -------------------------------------------------------------
    // Interactive Map Canvas Layers & Drone Survey
    // -------------------------------------------------------------
    setMapLayer(layer) {
        this.activeMapLayer = layer;
        ['btnLayerSat', 'btnLayerNdvi', 'btnLayerMoist'].forEach(id => {
            document.getElementById(id)?.classList.remove('active');
        });

        if (layer === 'natural') document.getElementById('btnLayerSat')?.classList.add('active');
        if (layer === 'ndvi') document.getElementById('btnLayerNdvi')?.classList.add('active');
        if (layer === 'moisture') document.getElementById('btnLayerMoist')?.classList.add('active');

        document.getElementById('activeLayerPill').innerText = `Layer: ${layer.toUpperCase()}`;
        this.renderMapOverlay();
    }

    initCanvasMapOverlay() {
        this.renderMapOverlay();
    }

    renderMapOverlay() {
        const canvas = document.getElementById('farmOverlayCanvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        if (this.activeMapLayer === 'ndvi') {
            // Render NDVI false-color thermal overlay
            ctx.fillStyle = 'rgba(16, 185, 129, 0.25)';
            ctx.fillRect(40, 40, 320, 180);

            ctx.fillStyle = 'rgba(245, 158, 11, 0.35)'; // Corn slight stress
            ctx.fillRect(400, 40, 350, 180);

            ctx.fillStyle = 'rgba(139, 92, 246, 0.25)';
            ctx.fillRect(40, 250, 240, 210);

            ctx.fillStyle = 'rgba(14, 165, 233, 0.3)';
            ctx.fillRect(310, 250, 210, 210);

            ctx.fillStyle = 'rgba(34, 197, 94, 0.25)';
            ctx.fillRect(550, 250, 210, 210);
        } else if (this.activeMapLayer === 'moisture') {
            // Render Moisture saturation heatmap
            ctx.fillStyle = 'rgba(14, 165, 233, 0.35)';
            ctx.fillRect(40, 40, 320, 180);

            ctx.fillStyle = 'rgba(239, 68, 68, 0.35)'; // Corn low moisture alert
            ctx.fillRect(400, 40, 350, 180);
        }

        // Draw Drone Position if flying
        if (this.droneAnimating) {
            ctx.fillStyle = '#38bdf8';
            ctx.beginPath();
            ctx.arc(this.dronePosition.x, this.dronePosition.y, 8, 0, Math.PI * 2);
            ctx.fill();

            ctx.strokeStyle = 'rgba(56, 189, 248, 0.6)';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(this.dronePosition.x, this.dronePosition.y, 22, 0, Math.PI * 2);
            ctx.stroke();
        }
    }

    dispatchDroneScan() {
        this.droneAnimating = true;
        this.dronePosition = { x: 50, y: 50 };

        const interval = setInterval(() => {
            this.dronePosition.x += 12;
            this.dronePosition.y += 6;
            this.renderMapOverlay();

            if (this.dronePosition.x >= 750) {
                clearInterval(interval);
                this.droneAnimating = false;
                this.renderMapOverlay();
                alert("Multispectral Autonomous Drone Survey completed! High-resolution NDVI and thermal layers synchronized.");
            }
        }, 80);
    }

    // -------------------------------------------------------------
    // AI Disease Vision Lab
    // -------------------------------------------------------------
    loadDiseaseSample(sampleId) {
        const sample = window.diseaseVisionLab.scanSample(sampleId);
        document.getElementById('activeScannerImg').src = sample.imagePath;
        document.getElementById('scannerCropTitle').innerText = sample.crop;
        this.updateDiseaseReportUI(sample);

        // Highlight thumbnail
        document.querySelectorAll('.gallery-thumb').forEach(thumb => {
            thumb.classList.remove('active');
        });
        event?.currentTarget?.classList.add('active');
    }

    handleCustomLeafUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            const dataUrl = e.target.result;
            document.getElementById('activeScannerImg').src = dataUrl;
            const customDiagnosis = window.diseaseVisionLab.scanCustomImage(dataUrl);
            this.updateDiseaseReportUI(customDiagnosis);
            this.runAiDiseaseScan();
        };
        reader.readAsDataURL(file);
    }

    runAiDiseaseScan() {
        const laser = document.getElementById('scannerLaser');
        laser.classList.add('scanning');
        document.getElementById('scannerStatusPill').innerText = 'Neural Scanning...';

        const sample = window.diseaseVisionLab.currentSelectedDisease;

        // Clear existing lesions
        const container = document.getElementById('lesionsContainer');
        container.innerHTML = '';

        setTimeout(() => {
            laser.classList.remove('scanning');
            document.getElementById('scannerStatusPill').innerText = 'Scan Complete';

            // Draw bounding boxes on lesions
            if (sample.lesions && sample.lesions.length > 0) {
                container.innerHTML = sample.lesions.map(l => `
                    <div class="lesion-box" style="left: ${l.x}px; top: ${l.y}px; width: ${l.w}px; height: ${l.h}px;">
                        <span class="lesion-tag">${l.label}</span>
                    </div>
                `).join('');
            }
        }, 1200);
    }

    updateDiseaseReportUI(diag) {
        document.getElementById('diagDiseaseName').innerText = diag.diseaseName;
        document.getElementById('diagPathogen').innerText = diag.pathogen;
        document.getElementById('diagConfidence').innerText = `${diag.confidence}%`;
        document.getElementById('diagSeverity').innerText = diag.severity;
        document.getElementById('diagSymptoms').innerText = diag.symptoms;

        document.getElementById('prescOrganic').innerText = diag.prescription.organic;
        document.getElementById('prescChemical').innerText = diag.prescription.chemical;
        document.getElementById('prescCultural').innerText = diag.prescription.cultural;

        // Reset bounding boxes until scan is executed
        document.getElementById('lesionsContainer').innerHTML = '';
    }

    dispatchDroneSpray() {
        alert("Agro-chemical flight plan calculated. Autonomous DJI Agras T40 drone dispatched for targeted ultra-low volume precision foliar spray.");
    }

    // -------------------------------------------------------------
    // VRT Matrix Table Rendering
    // -------------------------------------------------------------
    renderVrtTable() {
        const tbody = document.getElementById('vrtTableBody');
        if (!tbody) return;

        const zones = window.farmSimulator.zones;
        tbody.innerHTML = zones.map(z => `
            <tr>
                <td><strong>${z.name.split(':')[0]}</strong></td>
                <td>${z.crop}</td>
                <td><strong style="color: ${z.moisture < 25 ? '#ef4444' : 'var(--emerald-primary)'};">${z.moisture}%</strong></td>
                <td>25% Low / 55% High</td>
                <td><span class="hud-pill ${z.valveOpen ? 'active' : ''}">${z.valveOpen ? 'PUMPING (Open)' : 'CLOSED (Standby)'}</span></td>
                <td>${z.waterUsageGal.toLocaleString()} Gal</td>
                <td>
                    <button class="btn-secondary" style="padding: 0.25rem 0.6rem; font-size: 0.75rem;" onclick="app.toggleValveById('${z.id}')">
                        ${z.valveOpen ? 'Close' : 'Open'}
                    </button>
                </td>
            </tr>
        `).join('');
    }

    toggleValveById(zoneId) {
        window.farmSimulator.toggleIrrigation(zoneId);
        this.renderVrtTable();
    }
}

// Global Bootstrap
window.addEventListener('DOMContentLoaded', () => {
    window.app = new CloudAgriApp();
    window.app.init();
});
