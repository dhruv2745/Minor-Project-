@echo off
title CloudAgri Studio - AI Precision Agriculture
color 0A
echo ========================================================
echo   Launching CloudAgri Studio (Precision Agriculture AI)
echo ========================================================
echo.
echo Starting local telemetry server and opening web console...
echo.

python server.py

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Python was not found in PATH or failed to start.
    echo Opening index.html directly in your default browser...
    start index.html
)

pause
